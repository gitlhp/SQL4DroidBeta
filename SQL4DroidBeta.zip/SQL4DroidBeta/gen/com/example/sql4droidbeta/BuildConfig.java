/** Automatically generated file. DO NOT MODIFY */
package com.example.sql4droidbeta;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}