package com.example.myscrolltableview;


import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MyScrollTableView extends RelativeLayout implements OnScrollListener, OnHorizontalScrollListener{

	public static final int ROW_HEIGHT = 50;
	
	private Context context = null;
	
	private LeftCounterAdapter adapterLeft = null;
	
	private MyHorizontalScrollView myScrollViewMain = null;
	private HorizontalScrollView scrollViewTop = null;
	private GridView gridViewLeft = null;
	private GridView gridViewMain = null;
	private GridView gridViewTop = null;
	

	public MyScrollTableView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		
		// Left 
		adapterLeft = new LeftCounterAdapter(context);
		// adapterLeft.setCount(40);
		gridViewLeft = new GridView(context);
		RelativeLayout.LayoutParams lpLeft = new RelativeLayout.LayoutParams(50, -1);
		lpLeft.setMargins(0, 50, 0, 0);
		gridViewLeft.setBackgroundColor(Color.rgb(0xcc, 0xcc, 0xcc));
		gridViewLeft.setNumColumns(1);
		gridViewLeft.setAdapter(adapterLeft);
		gridViewLeft.setVerticalScrollBarEnabled(false);
		addView(gridViewLeft, lpLeft);
		
		// Main
		myScrollViewMain = new MyHorizontalScrollView(context);
		RelativeLayout.LayoutParams lpMain = new RelativeLayout.LayoutParams(-1, -1);
		lpMain.setMargins(50, 50, 0, 0);
		// scrollViewMain.setBackgroundColor(Color.CYAN);
		FrameLayout frame = new FrameLayout(context);
		frame.setBackgroundColor(Color.WHITE);
		myScrollViewMain.addView(frame, new RelativeLayout.LayoutParams(-1, -1));
		gridViewMain = new GridView(context);
		gridViewMain.setHorizontalSpacing(1);
		gridViewMain.setVerticalSpacing(1);
		frame.addView(gridViewMain, new FrameLayout.LayoutParams(-1, -1));
		addView(myScrollViewMain, lpMain);
		myScrollViewMain.setHorizontalScrollBarEnabled(false);
		
		// Top
		scrollViewTop = new HorizontalScrollView(context);
		scrollViewTop.setBackgroundColor(Color.rgb(0xcc, 0xcc, 0xcc));
		FrameLayout frameTop = new FrameLayout(context);
		gridViewTop = new GridView(context);
		frameTop.addView(gridViewTop, new FrameLayout.LayoutParams(-1, -1));
		scrollViewTop.addView(frameTop, new RelativeLayout.LayoutParams(-1, -1));
		scrollViewTop.setHorizontalScrollBarEnabled(false);
		RelativeLayout.LayoutParams lpTop = new RelativeLayout.LayoutParams(-1, 50);
		lpTop.setMargins(50, 0, 0, 0);
		addView(scrollViewTop, lpTop);

		// Test View
		/*insertView();
		scrollViewMain.setHorizontalScrollBarEnabled(true);
		scrollViewMain.setHorizontalFadingEdgeEnabled(true);*/
		
		// listener
		gridViewMain.setOnScrollListener(this);
		myScrollViewMain.setOnScrollListener(this);
		gridViewLeft.setEnabled(false);
		gridViewTop.setEnabled(false);
		scrollViewTop.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return true;
			}
		});
	}

	public MyScrollTableView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public MyScrollTableView(Context context) {
		this(context, null);
	}
	
	public void setAdapter(BaseAdapter adpter){
		gridViewMain.setAdapter(adpter);
		return ;
	}
	
	public void setWidth(int width){
		getMainGridView().setLayoutParams(new FrameLayout.LayoutParams(width, -1));
		getTopGridView().setLayoutParams(new FrameLayout.LayoutParams(width, -1));
	}
	
	public void setLeftListCount(int count){
		adapterLeft.setCount(count);
	}
	
	public GridView getMainGridView(){
		return gridViewMain;
	}
	
	public GridView getTopGridView(){
		return this.gridViewTop;
	}
	
	
	/* private void insertView(){
		LinearLayout panel = new LinearLayout(context);
		panel.setOrientation(LinearLayout.VERTICAL);
		scrollViewMain.addView(panel);
		for(int i = 0; i < 20; i ++){
			LinearLayout l = new LinearLayout(context);
			l.setOrientation(LinearLayout.HORIZONTAL);
			((LinearLayout)scrollViewMain.getChildAt(0)).addView(l, i);
			for(int j = 0; j < 20; j ++){
				((LinearLayout)((LinearLayout)scrollViewMain.getChildAt(0)).getChildAt(i)).addView(new Button(context));
			}
		}
	} */

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		if(view == gridViewMain){
			// int scrollY = view.get;
			// final int scrollY = -view.getTop() + firstVisibleItem * 50 / gridViewMain.getNumColumns();
			View v = gridViewMain.getChildAt(0);
			// Log.i("Scroll Event", "scrolling ~ y = " + scrollY);
			// gridViewLeft.scrollTo(0, scrollY);
			// Log.i("height :", ((v == null) ? 0 : v.getTop()) + "");
			gridViewLeft.smoothScrollToPositionFromTop(firstVisibleItem / gridViewMain.getNumColumns(), 1 * ((v == null) ? 0 : v.getTop()), 0);
			// gridViewLeft.invalidate();
			return ;
		}
		
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void onHorizontalScroll(int x, int y, int oldX, int oldY) {
		scrollViewTop.scrollTo(x, 0);
	}

	/* @Override
	public boolean onTouch(View v, MotionEvent event) {
		int xOffset = scrollViewMain.getScrollX();
		gridViewTop.scrollTo(xOffset, 0);
		Log.i("ScrollMain Touch Event", "touch : xOffset = " + xOffset);
		return false;
	} */

}



class LeftCounterAdapter extends BaseAdapter{
	// private List<Integer> list = new ArrayList<Integer>();
	private Context context = null;
	private int count = 0;
	
	public LeftCounterAdapter(Context context){
		super();
		this.context = context;
	}
	
	public void setCount(int n){
		this.count = n;
	}
	
	@Override
	public int getCount() {
		return count;
	}

	@Override
	public Object getItem(int position) {
		return position + "";
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Log.i("Adapter Event", "getView(" + position + ")");
		if(convertView == null){
			convertView = new TextView(context);
			convertView.setMinimumHeight(MyScrollTableView.ROW_HEIGHT);
			((TextView)convertView).setTextSize(16);
			((TextView)convertView).setGravity(Gravity.CENTER);
			
		}
		((TextView)convertView).setText("" + (position + 1));
		return convertView;
	}
	
}

interface OnHorizontalScrollListener {
	abstract public void onHorizontalScroll(int x, int y, int oldX, int oldY);
}

class MyHorizontalScrollView extends HorizontalScrollView {  
  
    private OnHorizontalScrollListener scrollViewListener = null;  
  
    public MyHorizontalScrollView(Context context) {  
        super(context);  
    }  
  
    public MyHorizontalScrollView(Context context, AttributeSet attrs,  
            int defStyle) {  
        super(context, attrs, defStyle);  
    }  
  
    public MyHorizontalScrollView(Context context, AttributeSet attrs) {  
        super(context, attrs);  
    }  
  
    public void setOnScrollListener(OnHorizontalScrollListener scrollViewListener) {  
        this.scrollViewListener = scrollViewListener;  
    }  
  
    @Override  
    protected void onScrollChanged(int x, int y, int oldx, int oldy) {  
        super.onScrollChanged(x, y, oldx, oldy);  
        if (scrollViewListener != null) {  
            scrollViewListener.onHorizontalScroll(x, y, oldx, oldy);
        }  
    }  
  
}  

