package com.example.sql4droidbeta;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.example.myscrolltableview.MyScrollTableView;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SqlResultExploreFragment extends PlaceholderFragment {
	/*
	 * 	View Pointer field
	 * */
	// private ..
	private MyScrollTableView myScrollTableView = null;
	private MyScrollTableViewTopAdapter adapterTop = null;
	private MyScrollTableViewAdapter adapterData = null;
	
	private Cursor cursor = null;
	private List<String> colName = new ArrayList<String>();
	private LinkedList<LinkedList<String>> data = new LinkedList<LinkedList<String>>();
	
	private Context context = null;
	
	public SqlResultExploreFragment() {
		super();
		type = PlaceholderFragment.TYPE_EXPLORER;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_explorer, container, false);
		myScrollTableView = (MyScrollTableView) view.findViewById(R.id.myScrollTableView1);
		myScrollTableView.setWidth(getResources().getDisplayMetrics().widthPixels - 60);
		
		// TODO : get view controls ...
		// gen data
		// get col num and data 
		if(cursor != null) {
				colName.clear();
				int colCount = cursor.getColumnCount();
				for(int i = 0; i < colCount; i ++) {
					colName.add(cursor.getColumnName(i));
				}
				adapterTop = new MyScrollTableViewTopAdapter(context, colName);
				myScrollTableView.getTopGridView().setAdapter(adapterTop);
				if(cursor.moveToFirst()) {
					LinkedList<String> childData = new LinkedList<String>();
					for(int i = 0; i < colCount; i ++) {
						childData.add(cursor.getString(i));
					}
					data.add(childData);
					while(cursor.moveToNext()) {
						LinkedList<String> childData2 = new LinkedList<String>();
						for(int i = 0; i < colCount; i ++) {
							childData2.add(cursor.getString(i));
						}
						data.add(childData2);
					}
				} else {
					LinkedList<String> childData = new LinkedList<String>();
					childData.add("No Data ��");
					data.add(childData);
				}
				adapterData = new MyScrollTableViewAdapter(context, data);
				myScrollTableView.setLeftListCount(cursor.getCount());
				myScrollTableView.getMainGridView().setAdapter(adapterData);
				myScrollTableView.getMainGridView().setNumColumns(colCount);
				myScrollTableView.getTopGridView().setNumColumns(colCount);
				int width = (int) (100 * colCount * getResources().getDisplayMetrics().density);
				myScrollTableView.setWidth(width >= getResources().getDisplayMetrics().widthPixels - 50 * getResources().getDisplayMetrics().density ? width : getResources().getDisplayMetrics().widthPixels );
		}
		return view;
	}
	
	
	@Override
	public void onAttach(Activity activity) {
		this.context = activity;
		super.onAttach(activity);
	}
	
	public void putResultRecord(Cursor c) {
		cursor =  c;
	}
}

class MyScrollTableViewTopAdapter extends BaseAdapter{
	private Context context = null;
	private List<String> colNameArray = null;
	
	public MyScrollTableViewTopAdapter(Context context, List<String> colNameArray){
		super();
		this.context = context;
		this.colNameArray = colNameArray;
	}
	
	@Override
	public int getCount() {
		return colNameArray.size();
	}

	@Override
	public Object getItem(int position) {
		return colNameArray.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView v = new TextView(context);
		v.setMaxHeight(50);
		v.setMinHeight(50);
		v.setGravity(Gravity.CENTER);
		v.setText(colNameArray.get(position));
		return v;
	}
	
}


class MyScrollTableViewAdapter extends BaseAdapter{
	private Context context = null;
	private LinkedList<LinkedList<String>> data = null;
	private List<Integer> colWidth = new LinkedList<Integer>();
	
	public MyScrollTableViewAdapter(Context context, LinkedList<LinkedList<String>> data){
		super();
		this.context = context;
		this.data = data;
		
		// calc width
		for(int i = 0; i < data.size(); i ++){
			for(int j = 0; j < data.get(i).size(); j ++){
				if(j >= colWidth.size())
					colWidth.add(Integer.valueOf(0));
				int width = 0;
				if(colWidth.get(j).intValue() < (width = 20 + getTextWidth(data.get(i).get(j)))){
					colWidth.set(j, Integer.valueOf(width));
				}
				Log.i("Text Width", width + "");
			}
		}
	}
	
	@Override
	public int getCount() {
		if(data.size() == 0)
			return 0;
		else
			return data.get(0).size() * data.size();
	}

	@Override
	public Object getItem(int position) {
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(null == convertView){
			convertView = new TextView(context);
			((TextView)convertView).setMinHeight(49);
			((TextView)convertView).setMaxHeight(49);
			((TextView)convertView).setGravity(Gravity.CENTER);
			((TextView)convertView).setMaxLines(1);
			((TextView)convertView).setBackgroundColor(position / data.get(0).size() % 2 == 0 ? Color.rgb(0xee, 0xee, 0xee) : Color.rgb(0xff, 0xff, 0xff));
		}
		String str = data.get(position / data.get(0).size()).get(position % data.get(0).size());
		// txtView.setMinWidth(colWidth.get(position % data.get(0).size()).intValue());
		((TextView)convertView).setText(str);
		return convertView;
	}

	public int getColWidth(int n) {
		return colWidth.get(n);
	}

	public int getNumCol() {
		if(data.size() > 0)
			return data.get(0).size();
		return 0;
	}
	
	private int getTextWidth(String string){
		paint.getTextBounds(string, 0, string.length(), rect);
		return rect.right - rect.left;
	}
	private Paint paint = new Paint();
	private Rect rect = new Rect();

	public int getWidth() {
		int n = 0;
		for(Integer i : colWidth)
			n += i.intValue();
		return n;
	}
}

