package com.example.sql4droidbeta;

import java.io.File;
import java.util.Calendar;

public class Console {
	private StringBuffer sb = new StringBuffer();
	
	public void put(String str) {
		Calendar c = Calendar.getInstance();
		String date = String.format("[%d-%d-%d %d:%d:%d.%d]", c.get(Calendar.YEAR), 1 + c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.HOUR), c.get(Calendar.MINUTE), c.get(Calendar.SECOND), c.get(Calendar.MILLISECOND));
		sb.append(date + " " + str + "\n");
		return ;
	}
	
	/*
	 *  function  : save2file
	 *  param : 
	 *  	filePath
	 *  note : need sdcard permission
	 */
	public int save(String dbPath) {
		int saveSize = 0;
		File file = new File(dbPath);
		if(!file.exists()) {
			
		} else {
			// TODO : 
		}
		return saveSize;
	}
	
	public String get() {
		return sb.toString();
	}
	
	@Override
	public String toString() {
		return sb.toString();
	}
	
	public static void main(String[] args) {
		Console c = new Console();
		c.put("Hello ConsoleUtil !");
		System.out.println(c.get());
	}
}
