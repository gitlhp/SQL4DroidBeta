package com.example.sql4droidbeta;

import android.database.sqlite.SQLiteDatabase;

public class AppGlobal {
	public static SQLiteDatabase db = null;
	
}
