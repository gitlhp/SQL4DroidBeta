package com.example.sql4droidbeta;

import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.TextView;

public class ExpandableListViewAdapter extends BaseExpandableListAdapter {
	private Context context = null;
	private List<String> group = null;
	private List<LinkedList<String>> child = null;
	
	public ExpandableListViewAdapter(Context context, List<String> group, List<LinkedList<String>> child) {
		super();
		this.context = context;
		this.group = group;
		this.child = child;
	}

	@Override
	public int getGroupCount() {
		return group.size();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return child.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return group.get(groupPosition);
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return child.get(childPosition);
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		if(convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.custom_expandablelistviewgroup, null);
		}
		TextView txtTitle = (TextView) convertView.findViewById(R.id.textView_customgroup1);
		txtTitle.setText(group.get(groupPosition));
		return convertView;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		View _convertView = null;
		if(_convertView == null) {
			switch(groupPosition) {
				case 0:
					_convertView = LayoutInflater.from(context).inflate(R.layout.custom_expandablelistviewchild_table, null);
					TextView txtTitle0 = (TextView) _convertView.findViewById(R.id.textView_customchild1);
					txtTitle0.setText(child.get(groupPosition).get(childPosition));
					final Button btn_look0 = (Button) _convertView.findViewById(R.id.button1);
					final Button btn_info0 = (Button) _convertView.findViewById(R.id.button1);
					final int bk_groupPosition = groupPosition;
					final int bk_childPosition = childPosition;
					btn_look0.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							((OnExpandableListViewButtonClickListener)ExpandableListViewAdapter.this.context).OnExpandableListViewButtonClick(bk_groupPosition, bk_childPosition, btn_look0);
						}
					});
					btn_info0.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							((OnExpandableListViewButtonClickListener)ExpandableListViewAdapter.this.context).OnExpandableListViewButtonClick(bk_groupPosition, bk_childPosition, btn_info0);
						}
					});
					break;
				case 1:
					_convertView = LayoutInflater.from(context).inflate(R.layout.custom_expandablelistviewchild_view, null);
					TextView txtTitle1 = (TextView) _convertView.findViewById(R.id.textView_customchild1);
					txtTitle1.setText(child.get(groupPosition).get(childPosition));
					break;
				case 2:
					_convertView = LayoutInflater.from(context).inflate(R.layout.custom_expandablelistviewchild_trigger, null);
					TextView txtTitle2 = (TextView) _convertView.findViewById(R.id.textView_customchild1);
					txtTitle2.setText(child.get(groupPosition).get(childPosition));
					break;
				default:
					_convertView = LayoutInflater.from(context).inflate(R.layout.custom_expandablelistviewchild_table, null);
					TextView txtTitle3 = (TextView) _convertView.findViewById(R.id.textView_customchild1);
					txtTitle3.setText(child.get(groupPosition).get(childPosition));
			}
			
		}
		return _convertView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return false;
	}
	
	interface  OnExpandableListViewButtonClickListener {
		abstract public int OnExpandableListViewButtonClick(int groupPosition, int childPositon, View view);
	}
}
