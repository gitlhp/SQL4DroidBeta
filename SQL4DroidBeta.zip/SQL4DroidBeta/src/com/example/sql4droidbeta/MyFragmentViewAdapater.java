package com.example.sql4droidbeta;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

public abstract class MyFragmentViewAdapater extends PagerAdapter {
    private static final String TAG = "FragmentPagerAdapter";
    private static final boolean DEBUG = true;
 
    private final FragmentManager mFragmentManager;
 
    public MyFragmentViewAdapater(FragmentManager fm) {
        mFragmentManager = fm;
    }
 
    /**
     * Return the Fragment associated with a specified position.
     */
    public abstract Fragment getItem(int position);
 
    @Override
    public void startUpdate(ViewGroup container) {
    }
 
    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Fragment fragment = getItem(position);
        if(!fragment.isAdded()){
            FragmentTransaction ft = mFragmentManager.beginTransaction();
            ft.add(fragment, fragment.getClass().getName());
            ft.commit();
            mFragmentManager.executePendingTransactions();
        }
        if(fragment.getView().getParent() == null){
            container.addView(fragment.getView()); // Ϊviewpager���Ӳ���
        }
 
        return fragment.getView();
    }
 
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
 
 
    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }
 
    @Override
    public Parcelable saveState() {
        return null;
    }
 
    @Override
    public void restoreState(Parcelable state, ClassLoader loader) {
    }
 
    private static String makeFragmentName(int viewId, int index) {
        return "android:switcher:" + viewId + ":" + index;
    }
}