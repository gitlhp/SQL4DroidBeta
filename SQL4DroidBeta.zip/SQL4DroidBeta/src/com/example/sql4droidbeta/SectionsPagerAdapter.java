package com.example.sql4droidbeta;

import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapter extends MyFragmentViewAdapater  {
	private Context context = null;
	private FragmentManager fm = null;
	public List<PlaceholderFragment> fragmentList = new LinkedList<PlaceholderFragment>();

	public SectionsPagerAdapter(Context context, FragmentManager fm, List<PlaceholderFragment> list) {
		super(fm);
		this.fm = fm;
		this.fragmentList = list;
		this.context = context;
	}

	@Override
	public Fragment getItem(int position) {
		// getItem is called to instantiate the fragment for the given page.
		// Return a PlaceholderFragment (defined as a static inner class below).
		Log.i("TEST", "getItem()");
		// return PlaceholderFragment.newInstance(position + 1);
		if(fragmentList.get(position).getType() == PlaceholderFragment.TYPE_EDIT) {
			// return SqlStatementsEditFragment.newInstance(position + 0);
			// TODO : this is a bug !!!
			return fragmentList.get(position);
		}else if(fragmentList.get(position).getType() == PlaceholderFragment.TYPE_EXPLORER) {
			// TODO : 
			// TIME @ 2016.05.25
			return fragmentList.get(position);
		}
		// return new SqlStatementsEditFragment();
		return null;
	}

	


	@Override
	public int getCount() {
		// Show 3 total pages.
		return fragmentList.size();
	}

	@Override
	public CharSequence getPageTitle(int position) {
		Locale l = Locale.getDefault();
		/*switch (position) {
            case 0:
                return getString(R.string.title_section1).toUpperCase(l);
            case 1:
                return getString(R.string.title_section2).toUpperCase(l);
            case 2:
                return getString(R.string.title_section3).toUpperCase(l);
        }*/
		// TODO : redirect method pointer !!!
		// 2016.05.25
		// return "Page " + position;
		PlaceholderFragment pf = fragmentList.get(position);
		if(pf.getType() == PlaceholderFragment.TYPE_EDIT) {
			return ((SqlStatementsEditFragment)pf).getTitle();
		}else if(pf.getType() == PlaceholderFragment.TYPE_EXPLORER) {
			return ((SqlResultExploreFragment)pf).getTitle();
		} 
		return "Untitled";
	}


	@Override
	public int getItemPosition(Object object) {
		return POSITION_NONE;
	}

}