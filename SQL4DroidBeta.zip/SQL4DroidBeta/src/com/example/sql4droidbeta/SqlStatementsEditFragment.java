package com.example.sql4droidbeta;

import java.util.Calendar;

import com.example.codetextview.CodeTextView;

import android.app.Activity;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class SqlStatementsEditFragment extends PlaceholderFragment {
	private Activity activity = null;
	
	private EditText txtSQL = null;
	
	public SqlStatementsEditFragment() {
		super();
		this.type = PlaceholderFragment.TYPE_EDIT;
	}
	
	
	@Override
	public void onAttach(Activity activity) {
		this.activity = activity;
		Bundle bundle = getArguments();
		// System.out.println(bundle);
		if(bundle != null) {
			title = bundle.getString(PlaceholderFragment.ARG_TITLE, "untitled" + Calendar.getInstance().get(Calendar.MINUTE) + ":" + Calendar.getInstance().get(Calendar.SECOND));
		}
		super.onAttach(activity);
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		 	View rootView = inflater.inflate(R.layout.fragment_edit, container, false);
		 	txtSQL = (EditText) ((CodeTextView)rootView.findViewById(R.id.editText1)).getRealEditText();
		 	((CodeTextView)rootView.findViewById(R.id.editText1)).startCodeDecorate();
	        return rootView;
	}
	
	
	public String getSQL() {
		if(txtSQL == null) {
			return "[TextView is null]";
		} else {
			// TODO : make selectable
			return txtSQL.getEditableText().toString();
		}
	}
}
