package com.example.codetextview;

public interface ScrollViewListener {  

	void onScrollChanged(ObservableScrollView scrollView, int x, int y, int oldx, int oldy);  

}  
