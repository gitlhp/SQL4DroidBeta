package com.example.codetextview;

import java.security.acl.Group;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Mac;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class CodeTextView extends RelativeLayout implements TextWatcher, ScrollViewListener {
	private Context context = null;
	private CodeDecorater cd = new CodeDecorater();

	private GridView leftGrid = null;
	public EditText txtView = null;
	private ObservableScrollView scrollView = null;
	private int leftWidth = 0;

	private BaseAdapter adapter = null;

	public CodeTextView(Context context) {
		this(context, null);
	}

	public CodeTextView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CodeTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		this.context = context;
		init();
	}

	private void init() {

		DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
		leftWidth = (int) (displayMetrics.widthPixels * 0.10);
		Log.i("Width", leftWidth + "");


		txtView = new  EditText(context);
		// txtView.setTextAppearance(context, R.style.textview_dark);
		// Test data
		// txtView.setText("1\n2\n3\n4\n5\n6\n7\n8\n9\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n01\n2\n3\n4\n5\n6\n7\n8\n9\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0");
		txtView.setBackgroundColor(Color.WHITE);
		// txtView.setTextColor(Color.WHITE);

		txtView.setGravity(Gravity.START);
		txtView.setIncludeFontPadding(false);
		txtView.setVerticalScrollBarEnabled(false);
		txtView.addTextChangedListener(this);

		txtView.setMinimumWidth(getResources().getDisplayMetrics().widthPixels);

		scrollView = new ObservableScrollView(context);
		// scrollView.setBackgroundColor(Color.GRAY);
		scrollView.setFillViewport(true);
		scrollView.addView(txtView, new ScrollView.LayoutParams(-2, -1));
		scrollView.setScrollViewListener(this);

		adapter = new LeftGridViewAdapter();

		leftGrid = new GridView(context);
		leftGrid.setVerticalSpacing(0);
		leftGrid.setBackgroundColor(0xaa00ffff);
		leftGrid.setAdapter(adapter);
		leftGrid.setVerticalScrollBarEnabled(false);

		this.setBackgroundColor(Color.CYAN);

		LayoutParams lp = new LayoutParams(-1, -1);
		lp.setMargins(leftWidth, 0, 0, 0);
		addView(scrollView, lp);
		// scrollView.setMinimumHeight(1000);
		LayoutParams lp2 = new LayoutParams(leftWidth, -1);
		lp2.setMargins(0, (int)(0.5 + getResources().getDisplayMetrics().density * 8), -1, -1);
		addView(leftGrid, lp2);
		return ;
	}
	
	public void startCodeDecorate() {
		cd.start();
	}
	
	public void stopCodeDecorate() {
		cd.stop();
	}
	
	public EditText getRealEditText() {
		return txtView;
	}

	@Override
	public void afterTextChanged(Editable s) {
		adapter.notifyDataSetChanged();
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onScrollChanged(ObservableScrollView scrollView, int x, final int y, int oldx, final int oldy) {
		leftGrid.smoothScrollToPositionFromTop(y / txtView.getLineHeight(), -1 * (y % txtView.getLineHeight()), 0);
	}

	class LeftGridViewAdapter extends BaseAdapter {
		// private List<String> list = new ArrayList<String>();

		@Override
		public int getCount() {
			return CodeTextView.this.txtView.getLineCount() + 1;
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if(convertView == null) {
				convertView = new TextView(CodeTextView.this.context);
				((TextView)convertView).setTextColor(Color.BLUE);
				((TextView)convertView).setGravity(Gravity.RIGHT);
				((TextView)convertView).setPadding(0, 0, 5, 0);
				convertView.setMinimumHeight(CodeTextView.this.txtView.getLineHeight());
			}
			((TextView)convertView).setText("" + (position + 1));
			return convertView;
		}


	}

	class CodeDecorater {
		private Thread thread = null;
		private boolean flag = true;

		// final private ForegroundColorSpan color_blue_span = new ForegroundColorSpan(Color.BLUE);    
		// private ForegroundColorSpan color_green_span = new ForegroundColorSpan(Color.GREEN);   
		private List<CharacterStyle> blue_Colorcase = new ArrayList<CharacterStyle>();
		
		private List<String> keywords = new ArrayList<String>();
		private int color_usage = 0;
		
		public CodeDecorater() {
			super();
			keywords.add("(?i)((\\bcreate\\b))"); // CREATE
			keywords.add("(?i)((\\binto\\b))"); // INTO
			keywords.add("(?i)((\\bvalues\\b))"); // VALUES
			keywords.add("(?i)((\\bselect\\b))"); // SELECT
			keywords.add("(?i)((\\bwhere\\b))"); // WHERE
			keywords.add("(?i)((\\bfrom\\b))"); // FROM 
			keywords.add("(?i)((\\binsert\\b))"); // INSERT
			keywords.add("(?i)((\\bdelete\\b))"); // DELETE
			keywords.add("(?i)((\\bupdate\\b))"); // UPDATE
			keywords.add("(?i)((\\bon\\b))"); // ON
			keywords.add("(?i)((\\bdesc\\b))"); // DESC
			keywords.add("(?i)((\\basc\\b))"); // ASC
			keywords.add("(?i)((\\bas\\b))"); // AS
			keywords.add("(?i)((\\btable\\b))"); // TABLE
			keywords.add("(?i)((\\bview\\b))"); // View
			keywords.add("(?i)((\\btrigger\\b))"); // trigger
			keywords.add("(?i)((\\blimit\\b))"); // SELECT
			keywords.add("(?i)((\\balter\\b))"); // ALTER
			keywords.add("(?i)\\s{0,}\\border\\b.*\\bby\\b\\s{0,}"); // ORDER BY
			keywords.add("(?i)\\s{0,}\\bgroup\\b.*\\bby\\b\\s{0,}"); // GROUP BY
		}

		@SuppressLint("HandlerLeak")
		private Handler handler = new Handler() {
			public void dispatchMessage(android.os.Message msg) {
				if(msg.what == 0) {
					if(CodeTextView.this.txtView != null) {
						int position = CodeTextView.this.txtView.getSelectionStart();
						int scroll = CodeTextView.this.scrollView.getScrollY();
						// Editable code = CodeTextView.this.txtView.getText();
						SpannableString code = new SpannableString(CodeTextView.this.txtView.getText());   
						// remove all span
						for(int d = 0; d < color_usage; d ++) {
							code.removeSpan(blue_Colorcase.get(d));
						}
						
						// match !
						Pattern pattern = /*Pattern.compile("(?i)\\s{0,}\\bhi\\b.*\\bLucy\\b\\s{0,}");*/ null;
						Matcher matcher = null;
						List<Integer[]> hit = new ArrayList<Integer[]>();
						for(int i = 0; i < keywords.size(); i ++ ) {
							pattern = Pattern.compile(keywords.get(i));
							matcher = pattern.matcher(code);
							while(matcher.find()) {
								hit.add(new Integer[]{Integer.valueOf(matcher.start()), Integer.valueOf(matcher.end())});
				 			}
						}
						color_usage = 0;
						for(Integer[] pi : hit) {
							// Log.i("HIT", pi[0] + " " + pi[1]);
							CharacterStyle cs  = null;
							if(color_usage < blue_Colorcase.size()) {
								cs = blue_Colorcase.get(color_usage);
							} else {
								cs = new ForegroundColorSpan(Color.BLUE);
								blue_Colorcase.add(cs);
							}
							color_usage ++;
							code.setSpan(cs, pi[0], pi[1], Spannable.SPAN_INCLUSIVE_INCLUSIVE);
							// break;
						}
							
						CodeTextView.this.txtView.setText(code);
						CodeTextView.this.scrollView.scrollTo(0, scroll);
						CodeTextView.this.txtView.setSelection(position);
					}
				}
			};
		};
/*
		 TEST SQL Statements
		 SELECT * FROM S
		 WHERE Sname='Tomson'
		 ORDER BY Sno DESC
		 
		 DELETE FROM S
		 WHERE Sno='20140001'
		 
*/

		private Runnable runnable = new Runnable() {
			public void run() {
				while(flag) {

					Message msg = new Message();
					msg.what = 0;
					handler.sendMessage(msg);
					try {
						Thread.sleep(1000 * 1);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
				Log.i("Thread", "exit");
			}
		};

		public boolean isRunning(){
			return null == thread ? false : true;
		}

		public void start() {
			if(!isRunning()) {
				flag = true;
				thread = new Thread(runnable, "cdr000");
				thread.start();
			}
		}

		public void stop() {
			if(isRunning()) {
				flag = false;
				thread = null;
			}

		}

	}

}
